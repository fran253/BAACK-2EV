// Content for ISalaRepository.cs based on the Sala class
