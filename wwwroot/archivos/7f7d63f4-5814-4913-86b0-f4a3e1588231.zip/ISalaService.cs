// Content for ISalaService.cs based on the Sala class
