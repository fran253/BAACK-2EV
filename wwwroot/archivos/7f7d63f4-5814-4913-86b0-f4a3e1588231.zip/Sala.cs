// Content for Sala.cs based on the Sala class
