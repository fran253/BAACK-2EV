// Content for SalaController.cs based on the Sala class
