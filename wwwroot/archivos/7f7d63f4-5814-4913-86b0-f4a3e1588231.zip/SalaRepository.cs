// Content for SalaRepository.cs based on the Sala class
