// Content for SalaService.cs based on the Sala class
